# ArbMasterPy

Master sheet for inventory management and arbitrage on Amazon


# TO-DO

Added 7.10.21
1. Implement inventory sheet as suggested by James. (only upload asins if not in sheet)
2. (maybe) Check for empty rows in inventory sheet, as this would screw up 
3. Fix bug where clicking cancel freezes the code
4. fix keep_on_top=True not working on mac
5. Make wording for import data clearer (not sure how to best do this one)

and then (6) deploy these changes as update to james
